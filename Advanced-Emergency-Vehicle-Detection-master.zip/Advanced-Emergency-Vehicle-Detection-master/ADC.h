#ifndef ADC_H
#define ADC_H

unsigned short ADC_read16b(void);

void DelayFunction (void);

void initADC(void);





#endif /*ADC_H*/